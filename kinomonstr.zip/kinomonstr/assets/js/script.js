let allLink = document.querySelectorAll(".show"); // все ссылки с фильмами
let filmDescriptionShow = document.querySelector(".filmDescription"); //основной контейнер куда будут динамически подставляться весь контент (фильмв, новости и т.д.)
let news = document.querySelectorAll(".filmDescriptionNews"); // все ссылки с новостями


// -----------------------создание страницы с фильмом в зависимости от выбраного (нажатия на ссылку) пользователем
allLink.forEach((linkFilm) => {
    linkFilm.onclick = function () {
        const filmDescription = async () => {
            const url = `http://localhost:3009/`
            const response = await fetch(url);
            const result = await response.json()
            result.forEach((elem) => { // перебираем все наявные в файле json объекты с фильмами
                let x = linkFilm.getAttribute('data-film') // получаем значенние атрибута 
                if (elem.classFilm == x) {
                    filmDescriptionShow.innerHTML = ""
                    filmDescriptionShow.insertAdjacentHTML('afterend', `    
                    <h1 class="showH1">${elem.title}</h1>
                    <hr>
                    <div class="d.flex justify-content-center">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="${elem.src}"
                                width="100%" height="480" frameborder="0" allowfullscreen></iframe>
                        </div>
                        <div class="info-block text-center">
                            Год: <span class="badge">${elem.year}</span>
                            Рейтинг: <span class="badge">${elem.raiting}</span>
                            Режиссер: <span class="badge">${elem.producer}</span>
                        </div>
                    </div>
                    <div class="margin-8"></div>
                    <h2>Описание ${elem.title}</h2>
                    <hr>
                    <div class="info-block">${elem.description}</div>
                    <div class="margin-8"></div>
                    <h2>Отзывы про ${elem.title}</h2>
                    <hr>
                    <div class="card card-info review">
                        <div class="card-header">
                            <div class="sidebar-header"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22"
                                    fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                                    <path
                                        d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                                </svg><span class="name">Сергей</span></div>
                        </div>
                        <div class="card-body">
                            <p class="card-text">Отличный фильм. Время пролетело незаметно!</p>
                        </div>
                    </div>
                    <div class="card card-info review">
                        <div class="card-header">
                            <div class="sidebar-header"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22"
                                    fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                                </svg><span class="name">Ксюша</span>
                            </div>
                        </div>
                        <div class="card-body">
                            <p class="card-text">Скукатища редкая!!!!!</p>
                        </div> `)
                }
            })
        }
        filmDescription()
    }
})







// ------------------------создание страницы с описанием новости -------------------
news.forEach((linkFilmNews) => {
    linkFilmNews.onclick = function () {
        const filmNews = async () => {
            const url = `http://localhost:3009/news`
            const response = await fetch(url);
            const result = await response.json()
            result.forEach((elem) => { // перебираем все наявные в файле json объекты с фильмами
                let x = linkFilmNews.getAttribute('data-class') // получаем значенние атрибута 
                if (elem.class == x) {
                    filmDescriptionShow.innerHTML = ""
                    filmDescriptionShow.insertAdjacentHTML('afterend', `    
                    <h1 class="showH1">${elem.title}</h1>
                    <hr>
                    <img class="img-fluid" src="${elem.img}" alt=${elem.title}">
                    <article>
                        <p>${elem.description}</p>
                        <address>автор: ${elem.autor}</address>
                    </article>             
                    `)
                }
            })
        }
        filmNews()
    }
})